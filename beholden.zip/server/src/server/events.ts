// Central, typed contract for server->client realtime events.
//
// IMPORTANT: This must stay aligned with what the web client expects.
// Do NOT invent new event names casually.

export type Id = string;

export type HelloPayload = { ok: true; time: number };

export type CampaignsChangedPayload = { campaignId: Id };

export type AdventuresChangedPayload =
  | { campaignId: Id }
  | { adventureId: Id };

export type EncountersChangedPayload =
  | { campaignId: Id; adventureId: Id }
  | { campaignId: Id }
  | { encounterId: Id };

export type NotesChangedPayload =
  | { campaignId: Id; adventureId: Id | null }
  | { campaignId: Id }
  | { noteId: Id };

export type PlayersChangedPayload = { campaignId: Id };

export type InpcsChangedPayload = { campaignId: Id };

export type TreasureChangedPayload = { campaignId: Id };

export type CompendiumChangedPayload =
  | { cleared: true }
  | { imported: number; total: number };

export type EncounterCombatantsChangedPayload = { encounterId: Id };

export type EncounterCombatStateChangedPayload = { encounterId: Id };

export interface ServerEventMap {
  hello: HelloPayload;

  "campaigns:changed": CampaignsChangedPayload;
  "adventures:changed": AdventuresChangedPayload;
  "encounters:changed": EncountersChangedPayload;
  "notes:changed": NotesChangedPayload;
  "players:changed": PlayersChangedPayload;
  "inpcs:changed": InpcsChangedPayload;
  "treasure:changed": TreasureChangedPayload;
  "compendium:changed": CompendiumChangedPayload;

  "encounter:combatantsChanged": EncounterCombatantsChangedPayload;
  "encounter:combatStateChanged": EncounterCombatStateChangedPayload;
}

export type ServerEventType = keyof ServerEventMap;

export type BroadcastFn = <K extends ServerEventType>(
  type: K,
  payload: ServerEventMap[K]
) => void;
